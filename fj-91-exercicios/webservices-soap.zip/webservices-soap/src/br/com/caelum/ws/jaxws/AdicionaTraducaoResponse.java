
package br.com.caelum.ws.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "adicionaTraducaoResponse", namespace = "http://ws.caelum.com.br/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "adicionaTraducaoResponse", namespace = "http://ws.caelum.com.br/")
public class AdicionaTraducaoResponse {


}
