function showOnConsole(texto){
	println("validando: " + texto);
}