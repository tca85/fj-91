package br.com.caelum.fj91.transformer;

public class Teste {

	public static void main(String[] args) {
		new MinhaClasse().invocaMetodo();
	}


}
class MinhaClasse {
	public void invocaMetodo() {
		System.out.println("INVOCACAO REALIZADA!");
	}
}
