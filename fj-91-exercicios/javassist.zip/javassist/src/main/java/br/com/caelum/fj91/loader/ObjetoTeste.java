package br.com.caelum.fj91.loader;

public class ObjetoTeste {

	public void teste() {
		System.out.println("---testando---");
	}
}
