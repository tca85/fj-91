package br.com.caelum.fj91.classloader.teste;

public class ObjetoTeste {

}
