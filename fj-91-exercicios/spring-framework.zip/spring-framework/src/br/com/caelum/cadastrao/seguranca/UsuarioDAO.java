package br.com.caelum.cadastrao.seguranca;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface UsuarioDAO extends UserDetailsService {

}